<?php

namespace App\Controllers;

use App\Controllers\Bmk\Blog;
use App\Models\BlogModel;

class Home extends BaseController
{
    /**
     * Show home page
     */
    public function index(): string
    {
        $news_model = new BlogModel();
        $news = $news_model->orderBy('id', 'DESC')->limit(5)->find();
        $data = [
            'title' => 'Home',
            'news' => $news
        ];
        return view('site/index', $data);
    }

    /**
     * Show about page
     * 
     */
    public function about(): string
    {
        $data = [
            'title' => 'About',

        ];
        return view('site/about', $data);
    }
    /**
     * Show about page
     * 
     */
    public function services(): string
    {
        $data = [
            'title' => 'Services',

        ];
        return view('site/services', $data);
    }
    /**
     * Show news page
     * 
     */
    public function news(): string
    {
        $news_model = new BlogModel();
        $news = $news_model->orderBy('id', 'DESC')->paginate(12);
        $data = [
            'title' => 'News',
            'news' => $news,
            'pager' => $news_model->pager
        ];
        return view('site/news', $data);
    }
    /**
     * Show news page
     * 
     */
    public function newsDetail($news_id): string
    {
        $news_model = new BlogModel();
        $news = $news_model->find($news_id);
        $data = [
            'title' => $news['title'],
            'news' => $news
        ];
        return view('site/news_single', $data);
    }
    /**
     * Show contactus page
     * 
     */
    public function contactus(): string
    {
        $data = [
            'title' => 'Contact Us',

        ];
        return view('site/contactus', $data);
    }
}
