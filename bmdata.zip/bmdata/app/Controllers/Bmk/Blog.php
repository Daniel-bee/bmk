<?php
namespace App\Controllers\Bmk;

use App\Models\BlogModel;
use App\Controllers\BaseController;

class Blog extends BaseController {

public function blogCreate()
    {
        $data = [
            'title' => "Create Blog"
        ];
        return view('admin/blogs/create', $data);
    }

    public function blogStore()
    {
        helper(['form']);
        $blogModel = new BlogModel();
        $blogs =  $blogModel->findAll();
        $session = session();

        $rules = [
            'blog_image' => [
                'label'  => 'Product Image',
                'rules'  => 'uploaded[blog_image]|mime_in[blog_image,image/jpg,image/jpeg,image/png]',
                'errors' => [
                    'uploaded' => 'Please choose a file to upload.',
                    'mime_in' => 'Invalid file type. Allowed types: jpg, jpeg, png.',
                ],
            ],
            'title' => 'required',
            'content' => 'required',
        ];
        if ($this->validate($rules)) {

            $file = $this->request->getFile('blog_image');

            if ($file->isValid() && !$file->hasMoved()) {
                // Move the uploaded file to the desired directory
                $arrayName = explode('.', $file->getName());
                $fileName = time() . '.' . end($arrayName);
                $is_upload = $file->move('./bmk/images/blog', $fileName);
                
                if ($is_upload) {
                    $data = [
                        'title' => $this->request->getPost('title'),
                        'content' => $this->request->getPost('content'),
                        'user_id' => $session->get('userid'),
                        'image_url' => $fileName,
                        'created_at' => date('Y-m-d H:i:s'),
                    ];
                    $blogModel->save($data);
                    $session->setFlashdata('success', 'Boom! You have successfully added a new blog.');
                    return redirect()->to(base_url() .'bmkad/blog/detail');
                } else {
                    $session->setFlashdata('error', $file->getErrorString());
                    $data = [
                        'title' => 'Create Blog',
                        'validation' => $this->validator,
                        'blogs' => $blogs
                    ];
                    return view('admin/blogs/create', $data);
                }
            } else {
                $session->setFlashdata('error', $file->getErrorString());
                $data = [
                    'title' => 'Create Blog',
                    'validation' => $this->validator,
                    'blogs' => $blogs
                ];
                return view('admin/blogs/create', $data);
            }
        } else {
            
            $data = [
                'title' => 'Create Blog',
                'validation' => $this->validator,
                'blogs' => $blogs
            ];
            return view('admin/blogs/create', $data);
        }
    }

    public function blogDetail()
    {
        $blogModel = new BlogModel();
        $results = $blogModel->orderBy('id', 'DESC')->find();
        $data = [
            'title' => "Blog Details",
            'blogs' => $results
        ];
        return view('admin/blogs/details', $data);
    }

    public function blogEdit($id){
        $blogModel = new BlogModel();
        $data = [
            'title' => "Blog Edit",
            'blog' => $blogModel->find($id)
        ];
        return view('admin/blogs/edit.php', $data);
    }

    public function blogUpdate($id){
        helper(['form']);
        $blogModel = new BlogModel();
        $blog = $blogModel->find($id);
        $session = session();

        $rules = [
            'title' => 'required',
            'content' => 'required',
        ];

        if ($this->validate($rules)) {
            $file_ = $this->request->getFile('blog_image');
            if($file_->getName() == NULL)
            {
                $data = [
                    'title' => $this->request->getPost('title'),
                    'content' => $this->request->getPost('content'),
                    'user_id' => $session->get('id'),
                    'image_url' => $blog['image_url'],
                    'updated_at' => date('Y-m-d H:i:s')
                ];

                $blogModel->update($id, $data);

                return redirect()->to(base_url() . 'bmkad/blog/detail')->with('success', ' All updated!');
            }else{
                $file = $this->request->getFile('blog_image');

                if ($file->isValid() && !$file->hasMoved()) {
                    
                    $arrayName = explode('.', $file->getName());
                    $fileName = time() . '.' . end($arrayName);
                    $is_upload = $file->move('./bmk/images/blog/', $fileName);
                   
                    if ($is_upload) {
                        unlink('./bmk/images/blog/' . $blog['image_url']);
                        $data = [
                            'title' => $this->request->getPost('title'),
                            'content' => $this->request->getPost('content'),
                            'user_id' => $session->get('id'),
                            'image_url' => $fileName,
                            'updated_at' => date('Y-m-d H:i:s')
                        ];
                        $blogModel->update($id, $data);
    
                        return redirect()->to(base_url() .'bmkad/blog/detail')->with('success', ' All updated!');
                    } else {
                        $session->setFlashdata('error', $file->getErrorString());
                        $data = [
                            'title' => "Edit Blog",
                            'validation' => $this->validator,
                            'blogs' => $blog
                        ];
                        return view('admin/blogs/edit', $data);
                    }
                } else {
                    $session->setFlashdata('error', $file->getErrorString());
                    $data = [
                        'title' => "Edit Blog",
                        'validation' => $this->validator,
                        'blogs' => $blog
                    ];
                    return view('admin/blogs/edit', $data);
                    
                }
            }
        } else {
            $data = [
                'title' => "Edit Blog",
                'validation' => $this->validator,
                'blogs' => $blog
            ];
            return view('admin/blogs/edit', $data);
        }
    }

    public function blogDestroy($id){
        helper(['form']);
        $blogModel = new BlogModel();
        $blog = $blogModel->find($id);
        if($blogModel->delete($id)){
            unlink('./bmk/images/blog/' . $blog['image_url']);
        }
        return redirect()->to(base_url() .'bmkad/blog/detail')->with('status', ' All updated! Your information is now up to date.');
    }

}