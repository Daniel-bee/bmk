<?php
namespace App\Controllers\Bmk;

use App\Models\BookingModel;
use App\Controllers\BaseController;

class Dashboard extends BaseController {
  
    public function index(){
        return view('admin/dashboard');
    }

}