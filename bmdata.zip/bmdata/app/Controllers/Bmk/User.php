<?php

namespace App\Controllers\Bmk;

use App\Models\UserModel;
use App\Controllers\BaseController;

class User extends BaseController
{
    public function signin()
    {
        $session = session();
        if ($session->isLoggedIn) {
            return redirect()->to(base_url() . 'bmk/dashboard');
        }
        return view('admin/login');
    }
    public function signup()
    {
        return view('admin/signup');
    }

    /**
     * Store User
     * 
     */
    public function storeUser()
    {

        helper(['form']);

        $rules = [
            'password' => [
                'label'  => 'Password',
                'rules'  => 'required|regex_match[/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/]',
                'errors' => [
                    'regex_match' => 'The password must contain at least one digit, one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long.',
                ],
            ],
            'email' => [
                'label' => 'Email',
                'rules' => 'required|valid_email|is_unique[users.email]',
            ],
            'confirmpassword' => [
                'label' => 'Confirm Password',
                'rules' => 'matches[password]',
            ],

        ];

        if ($this->validate($rules)) {
            $user = new UserModel();
            $data = [
                'email' => $this->request->getPost('email'),
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            $user->save($data);
            return redirect()->to(base_url() . 'bmkad/')->with('success', "Account has been created successfully.Now you can login.");
        } else {
            $data = [
                'validation' => $this->validator
            ];
            return view('admin/signup.php', $data);
        }
    }
    /**
     * User authenticate
     * 
     */
    public function authenticate()
    {

        $session = session();
        $user = new UserModel();

        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        $data = $user->where('email', $email)->first();
        if($data && $data['status'] == 0)
        {
            return redirect()->to(base_url() . 'bmkad')->with('error', 'You are not authorized to view this page.');
        }

        if ($data) {
            $pass = $data['password'];
            $authPassword = password_verify($password, $pass);
            if ($authPassword) {
                $session_data = [
                    'userid' => $data['id'],
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'role' => $data['status'], // role 0 for admin 1 for staff
                    'status' => $data['status'], // status 0 means you can't login
                    'isLoggedIn' => TRUE
                ];
                $session->set($session_data);
                return redirect()->to(base_url() . 'bmkad/dashboard');
            } else {
                $session->setFlashdata('error', 'There seems to be an error with your login credentials. Please try again.');
                return redirect()->to(base_url() . 'bmkad');
            }
        } else {
            $session->setFlashdata('error', 'There seems to be an error with your login credentials. Please try again.');
            return redirect()->to(base_url() . 'bmkad');
        }
    }
    /**
     * User Profile
     * 
     */
    public function profile($user_id)
    {
        $user_model = new UserModel();
        $viewData = [
            'title' => 'Profile',
            'user' => $user_model->find($user_id)
        ];
        return view('admin/users/profile', $viewData);
    }
    /**
     * Update User Info
     * 
     */
    public function updateUser($userid)
    {

        $userModel = new UserModel();
        $user = $userModel->find($userid);
        $session = session();

        helper(['form']);
        $rules = [
            'firstname' => [
                'label' => 'First Name',
                'rules' => 'required',
            ],
            'lastname' => [
                'label' => 'Last Name',
                'rules' => 'required',
            ],

        ];

        if ($this->validate($rules)) {
            $data = [
                'first_name' => $this->request->getPost('firstname'),
                'last_name' => $this->request->getPost('lastname'),
                'updated_at' => date('Y-m-d H:i:s'),
            ];
            return redirect()->to(base_url() . 'bmkad/profile/' . $userid)->with('success', 'Update successful.');;
        } else {
            $viewData = [
                'title' => "Profile",
                'user' => $user,
                'validation' => $this->validator,
            ];
            return view('admin/users/profile.php', $viewData);
        }
    }
    /**
     * Chnage Password
     * 
     */
    public function updatePassword($userid)
    {
        helper(['form']);
        $userModel = new UserModel();
        $user = $userModel->find($userid);

        $session = session();
        $password = $this->request->getVar('oldpassword');
        $oldpass = password_verify($password, $user['password']);

        if (!$oldpass) {
            $session->setFlashdata('oldpass', 'The old password you entered does not match our records');
            return redirect()->to(base_url() . 'bmkad/profile/' . $userid);
        }

        $rules = [
            'newpassword' => [
                'label'  => 'New Password',
                'rules'  => 'required|regex_match[/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/]',
                'errors' => [
                    'regex_match' => 'The password must contain at least one digit, one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long.',
                ],
            ],
            'confirmnewpassword' => [
                'label' => 'Confirm New Password',
                'rules' => 'matches[newpassword]'
            ],
        ];

        if ($this->validate($rules)) {
            $data = [
                'password' => password_hash($this->request->getVar('newpassword'), PASSWORD_DEFAULT),
            ];
            $userModel->update($userid, $data);
            $session->setFlashdata('success', 'Password updated! Your account is now more secure.');
            return redirect()->to(base_url() . 'bmkad/profile/' . $userid);
        } else {
            $data = [
                'title' => 'Profile',
                'validation' => $this->validator,
                'user' => $user
            ];

            return view('admin/users/profile.php', $data);
        }
    }
    /**
     * Update Profile Image
     * 
     */
    public function updateImage()
    {
        $user_model = new UserModel();
        $session = session();
        $user = $user_model->find($session->id);

        $file = $this->request->getFile('file');

        if ($file->isValid() && !$file->hasMoved()) {

            $arrayName = explode('.', $file->getName());
            $fileName = time() . '.' . end($arrayName);
            $is_upload = $file->move('./travelad/images/faces', $fileName);

            if ($is_upload) {
                // unlink('./travelad/images/face' . $user['image_url']);
                $data = [
                    'image_url' => $fileName,
                ];
                $user_model->update($session->id, $data);
                return $this->response->setJSON(['message' => 'File uploaded successfully.']);
            } else {
                return $this->response->setJSON(['error' => 'Error uploading file.']);
            }
        } else {
            return $this->response->setJSON(['error' => 'Error uploading file.']);
        }
    }
    /**
     * User logout
     * 
     */
    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to(base_url() . 'bmkad/');
    }
}
