<?php
// app/Filters/AdminFilter.php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Check if the user is logged in and is an admin
        if (!session()->get('isLoggedIn')  && session()->get('status') == 0) {
            return redirect()->to(base_url() . 'bmkad')->with('error', 'You are not authorized to view this page.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something after the route is run
    }
}
