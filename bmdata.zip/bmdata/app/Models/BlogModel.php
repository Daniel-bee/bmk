<?php
namespace App\Models;
use CodeIgniter\Model;

class BlogModel extends Model{
    protected $table = 'blogs';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'title',
        'content',
        'user_id',
        'image_url',
        'status',
        'created_at',
        'updated_at',
    ];
}
?>