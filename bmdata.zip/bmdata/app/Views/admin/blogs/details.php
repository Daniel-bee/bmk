<?= $this->extend('admin/layouts/base') ?>
<?= $this->section('title') ?>
  <?php if(isset($title)):?>
    <?= $title ?>
  <?php else:?>
    Blog Detail
  <?php endif?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>

<div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Blogs</h4>
                  <div class="table-responsive">
                    <table class="table table-hover" id="myTable">
                      <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col" width="60%">Content</th>
                        <th scope="col">Created At</th>
                        <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>

                      <?php if(isset($blogs)): ?>
                        <?php $count=1; foreach($blogs as $blog):?>
                        <tr>
                          <td class="py-1">
                            <?= $blog['id'] ?>
                          </td>
                          <td>
                          <?= $blog['title'] ?>
                          </td>
                          <td width="50%"><?= $blog['content'] ?></td>
                          <td>
                             <?php $d = new dateTime($blog['created_at']); echo $d->format('M-d Y');?>
                          </td>
                          <td>
                                <a class="btn btn-outline-secondary btn-sm" href="<?= base_url()?>bmkad/blog/edit/<?= $blog['id']?>">
                                <i class="mdi mdi-file-check btn-icon-append text-info"></i></a>

                                <button type="button" value="<?= $blog['id']?>" class="confirm_delete btn btn-outline-danger btn-sm"><i class="mdi mdi-delete btn-icon-append txte-light"></i></button>
              
                            </td>
                        </tr>
                        <?php endforeach;?>
                        <?php endif;?>
  


                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
          <!-- row end -->

<?= $this->endSection() ?>

<?= $this->section('script')?>
<script>
    $(document).ready(function(){
        <?php if(session()->getFlashdata('success')): ?>
        alertify.set('notifier','position', 'top-center');
        alertify.success('<span class="text-light">'+'<?= session()->getFlashdata('success') ?>'+'</span>');
        <?php endif?>
    });
</script>
<script>
    $(document).ready(function(){
        $('.confirm_delete').click(function(e){
            e.preventDefault()
            let id = $(this).val()

            const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: "btn btn-success",
                cancelButton: "btn btn-danger"
            },
            buttonsStyling: false
            });

            swalWithBootstrapButtons.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel!",
            reverseButtons: true
            }).then((result) => {
            if (result.isConfirmed) {

                $.ajax({
                    url:'<?= base_url()?>bmkad/blog/delete/'+id,

                    success: function(response) {
                        swalWithBootstrapButtons.fire({
                        title: "Deleted!",
                        text: "Your file has been deleted.",
                        icon: "success"
                        }).then(
                            window.location.reload()
                        )
                    }
                });

            } else if (
                /* Read more about handling dismissals below */
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire({
                title: "Cancelled",
                text: "Your imaginary file is safe :)",
                icon: "error"
                });
            }
            });


        })
    })
</script>
<?= $this->endSection() ?>