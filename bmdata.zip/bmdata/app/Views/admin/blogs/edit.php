<?= $this->extend('admin/layouts/base') ?>
<?= $this->section('title') ?>
<?php if (isset($title)) : ?>
    <?= $title ?>
<?php else : ?>
    Edit Blog
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Blog</h4>
            <p class="card-description">
                Edit blog
            </p>
            <?php if (isset($validation)) : ?>
                <div class="alert alert-danger">
                    <?= $validation->listErrors() ?>
                </div>
            <?php endif; ?>
            <form class="forms-sample" action="<?= base_url() ?>bmkad/blog/update/<?= $blog['id'] ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="_method" value="PUT">
                <div class="form-group">
                    <label for="exampleInputName1">Title</label>
                    <input type="text" class="form-control" name="title" value="<?= $blog['title'] ?>" placeholder="Name">
                </div>

                <div class="form-group">
                    <label for="exampleTextarea1">Description</label>
                    <textarea class="form-control" name="content" rows="4"><?= $blog['content'] ?></textarea>
                </div>
                <div class="form-group">
                    <label>Select Images</label><br>
                    <p><img src="<?= base_url() ?>travelad/images/blog/<?= $blog['image_url'] ?>" height="50" alt=""></p>
                    <div class="input-group col-xs-12">
                        <input type="file" accept=".jpg,.png,.jpeg" class="form-control file-upload-info" name="blog_image">

                    </div>
                </div>

                <button type="submit" class="btn btn-primary me-2">Save</button>

            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>