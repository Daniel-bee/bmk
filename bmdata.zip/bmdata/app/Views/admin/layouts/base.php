<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?= $this->renderSection('title')?></title>
  <!-- base:css -->
  <link rel="stylesheet" href="<?= base_url()?>bmk/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?= base_url()?>bmk/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?= base_url()?>bmk/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?= base_url()?>bmk/images/favicon.png" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css" />
</head>
<body>
  <div class="container-scroller d-flex">
    <div class="row p-0 m-0 proBanner" id="proBanner">
      <div class="col-md-12 p-0 m-0">

      </div>
    </div>
    <!-- partial:./partials/_sidebar.html -->
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <ul class="nav">
        <?php $session = session();?>
        <li class="nav-item">
          <a class="nav-link" href="index.html">
            <i class="mdi mdi-speedometer menu-icon"></i>
            <span class="menu-title">Dashboard</span>
          </a>
        </li>
        <li class="nav-item sidebar-category">

        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url()?>bmkad/blog/create/">
            <i class="mdi mdi-plus menu-icon"></i>
            <span class="menu-title">Blog</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= base_url()?>bmkad/signup/">
            <i class="mdi mdi-account menu-icon"></i>
            <span class="menu-title">User</span>
          </a>
        </li>
      </ul>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:./partials/_navbar.html -->
      <nav class="navbar col-lg-12 col-12 px-0 py-0 py-lg-4 d-flex flex-row">
        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="navbar-brand-wrapper">
            <a class="navbar-brand brand-logo" href="index.html"><img src="<?= base_url()?>bmk/images/logo.jpg" width="70" alt="logo"/></a>
            <a class="navbar-brand brand-logo-mini" href="index.html"><img src="<?= base_url()?>bmk/images/logo.jpg" alt="logo"/></a>
          </div>
          <!-- <h4 class="font-weight-bold mb-0 d-none d-md-block mt-1">Welcome back</h4> -->
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item">
              <h4 class="mb-0 font-weight-bold d-none d-xl-block"><?= date('M-d Y')?></h4>
            </li>

            <li class="nav-item dropdown me-1">

            </li>

          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
        <div class="navbar-menu-wrapper navbar-search-wrapper d-none d-lg-flex align-items-center">
          <ul class="navbar-nav mr-lg-2">
            <li class="nav-item nav-search d-none d-lg-block">
            <a href="<?= base_url()?>bmkad/blog/detail" class="btn btn-outline-secondary btn-sm">Blogs</a>
            </li>
          </ul>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                <img src="<?= base_url()?>bmk/images/faces/user.jpg" alt="profile"/>
                <span class="nav-profile-name"><?= $session->first_name?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="<?= base_url()?>bmkad/profile/<?= $session->userid?>">
                  <i class="mdi mdi-settings text-primary"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="<?= base_url()?>bmkad/logout/">
                  <i class="mdi mdi-logout text-primary"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>
        </div>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">

          <?= $this->renderSection('content') ?>

          </div>


        </div>
        <!-- content-wrapper ends -->
        <!-- partial:./partials/_footer.html -->
        <footer class="footer">
          <div class="card">
            <div class="card-body">
              <div class="d-sm-flex justify-content-center justify-content-sm-between py-2">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="<?= base_url()?>bmkad/dashboard">BMK GEO-INFORMATICS </a> <?= date('Y')?></span>
              </div>
            </div>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <script src="<?= base_url()?>bmk/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?= base_url()?>bmk/vendors/chart.js/Chart.min.js"></script>
  <script src="<?= base_url()?>bmk/js/jquery.cookie.js" type="text/javascript"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?= base_url()?>bmk/js/off-canvas.js"></script>
  <script src="<?= base_url()?>bmk/js/hoverable-collapse.js"></script>
  <script src="<?= base_url()?>bmk/js/template.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
    <script src="<?= base_url()?>bmk/js/jquery.cookie.js" type="text/javascript"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="<?= base_url()?>bmk/js/dashboard.js"></script>
  <!-- End custom js for this page-->

  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

    <?= $this->renderSection('script')?>
    <script>
        $(document).ready( function () {
            // $('#myTable').DataTable();
            new DataTable('#myTable', {
                order: [[0, 'desc']]
            });
        } );
    </script>
</body>

</html>