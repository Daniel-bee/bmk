<?= $this->extend('admin/layouts/base') ?>
<?= $this->section('title') ?>
<?php if (isset($title)) : ?>
    <?= $title ?>
<?php else : ?>
    Profile
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <img class="img-responsiv" src="<?= base_url() ?>bmk/images/faces/<?php if ($user['image_url']) {
                                                                                                echo $user['image_url'];
                                                                                            } else {
                                                                                                echo 'user.jpg';
                                                                                            } ?>" height="200" width="200" alt="">
                    <form action="" enctype="multipart/form-data">
                        <label for="file-input" id="file-input-label">
                            <i class="mdi mdi-image"></i>
                            <span id="file-name"></span>
                        </label>

                        <input type="file" id="file-input" name="file" style="display:none;">

                    </form>
                    <p class="display-4"><?= $user['first_name'] ?> <?= $user['last_name'] ?> </p>


                </div>
                <hr class="hr hr-blurry" />
                <div>
                    <p> <i class="mdi mdi-email"></i> <?= $user['email'] ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-8 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Profile</h4>
                <p class="card-description">
                    Update Info
                </p>
                <?php
                $session = session();
                ?>
                <?php if (isset($validation)) : ?>
                    <div class="alert alert-danger">
                        <?= $validation->listErrors() ?>
                    </div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('oldpass')) : ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('oldpass') ?>
                    </div>
                <?php endif ?>
                <form class="forms-sample" action="<?= base_url() ?>bmkad/user/update/<?= $session->userid ?>" method="post">
                    <input type="hidden" name="_method" value="PUT">
                    <div class="form-group">
                        <label for="exampleInputUsername1">First Name</label>
                        <input type="text" class="form-control" name="firstname" value="<?= $user['first_name'] ?>" placeholder="First Name">

                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Last Name</label>
                        <input type="text" class="form-control" name="lastname" value="<?= $user['last_name'] ?>" placeholder="Last Name">

                    </div>
                    <div class="form-check form-check-flat form-check-primary">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input">

                        </label>
                    </div>
                    <div class="text-end">
                        <button type="submit" class="btn btn-primary me-2">Update</button>
                    </div>


                </form>
                <hr class="hr hr-blurry" />
                <h4 class="card-title">Chnage Password</h4>
                <form class="forms-sample" method="post" action="<?= base_url() ?>bmkad/user/changepassword/<?= $session->userid ?>">
                <input type="hidden" name="_method" value="PUT">

                    <div class="form-group">
                        <label for="exampleInputUsername1">Old Password</label>
                        <input type="password" class="form-control" name="oldpassword" placeholder="Old Password">

                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" name="newpassword" placeholder="New Password">

                    </div>
                    <div class="form-group">
                        <label for="exampleInputConfirmPassword1">Confirm New Password</label>
                        <input type="password" class="form-control" name="confirmnewpassword" placeholder="Confirm New Password">

                    </div>
                    <div class="form-check form-check-flat form-check-primary">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input">

                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary me-2">Change</button>

                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('script') ?>
<script>
    $(document).ready(function() {
        <?php if (session()->getFlashdata('success')) : ?>
            alertify.set('notifier', 'position', 'top-center');
            alertify.success('<span class="text-light">' + '<?= session()->getFlashdata('success') ?>' + '</span>')
        <?php endif ?>

    });


    $(document).ready(function() {

        $('#file-input').change(function() {

            // var formData = new FormData();
            // formData.append('file', file);

            // $.ajax({
            //     type:'GET',
            //     url: 'bmkad/user/upload', // Controller method handling file upload
            //     data: formData,
            //     cache:false,
            //     contentType: false,
            //     processData: false,  

            //     success: function(response) {
            //         // console.log(response);
            //         window.location.reload()
            //         // Update the preview image
            //         // $('#preview-image').attr('src', 'uploads/' + file.name);
            //         // $('#file-name').text(file.name);
            //     },
            //     error: function(error) {
            //         console.error(error);
            //         // Handle error
            //     }
            // });

        });
    });
</script>
<?= $this->endSection() ?>