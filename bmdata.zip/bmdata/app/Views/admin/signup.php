<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sign Up</title>
    <!-- base:css -->
    <link rel="stylesheet" href="<?= base_url() ?>bmk/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>bmk/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url() ?>bmk/css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?= base_url() ?>bmk/images/favicon.png" />

    <link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/css/intlTelInput.css" />
    <script src="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>

    <style>
        #phone {
            width: 380px !important;
        }
    </style>
</head>

<body>
    <div class="container-scroller d-flex">
        <div class="container-fluid page-body-wrapper full-page-wrapper d-flex">
            <div class="content-wrapper d-flex align-items-center auth px-0">
                <div class="row w-100 mx-0">
                    <div class="col-lg-4 mx-auto">
                        <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                            <div class="brand-logo">
                                <!-- <img src="../../images/logo-dark.svg" alt="logo"> -->
                            </div>
                            <h4>Add New User</h4>
                            <h6 class="font-weight-light">It only takes a few steps</h6>
                            <form class="pt-3" action="<?= base_url() ?>bmkad/user/create" method="post">
                                <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
                                <div class="form-group">
                                    <input type="email" class="form-control form-control-lg" name="email" placeholder="Email">
                                    <?php if (isset($validation)) : ?>
                                        <span class="text-danger"><?= esc($validation->getError('email')) ?><spaa>
                                            <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-lg" name="password" placeholder="Password">
                                    <?php if (isset($validation)) : ?>
                                        <span class="text-danger text-sm"><?= esc($validation->getError('password')) ?><spaa>
                                            <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <input type="password" class="form-control form-control-lg" name="confirmpassword" placeholder="Confirm Password">
                                    <?php if (isset($validation)) : ?>
                                        <span class="text-danger"><?= esc($validation->getError('confirmpassword')) ?><spaa>
                                            <?php endif; ?>
                                </div>
                                <!-- <div class="mb-4">
                  <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      I agree to all Terms & Conditions
                    </label>
                  </div>
                </div> -->
                                <div class="mt-3">
                                    <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">SIGN UP</button>
                                </div>
                                <!-- <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="login.html" class="text-primary">Login</a>
                </div> -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content-wrapper ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

    <!-- base:js -->
    <script src="<?= base_url() ?>bmk/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <script src="<?= base_url() ?>bmk/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- inject:js -->
    <script src="<?= base_url() ?>bmk/js/off-canvas.js"></script>
    <script src="<?= base_url() ?>bmk/js/hoverable-collapse.js"></script>
    <script src="<?= base_url() ?>bmk/js/template.js"></script>
    <!-- Include intl-tel-input and utils.js from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var input = document.querySelector("#phone");
            var iti = window.intlTelInput(input, {
                separateDialCode: true,
                preferredCountries: ["et", "us"],
            });

            // Example of getting the selected country code
            document.querySelector('form').addEventListener('submit', function() {
                let cantry_code = document.querySelector("#phone");
                if (cantry_code.value) {
                    let phone = document.querySelector("#phone");
                    let cantry_phone = document.querySelector("#country_phone");
                    cantry_code = iti.getSelectedCountryData().dialCode;
                    cantry_phone.value = cantry_code + '' + phone.value;
                }
            });
        });
    </script>

</body>

</html>