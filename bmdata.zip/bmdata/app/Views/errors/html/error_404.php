<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title -->
        <title>404</title>
		
		<!-- Favicon -->
        <link rel="icon" href="img/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?= base_url()?>assets/css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="<?= base_url()?>assets/css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="<?= base_url()?>assets/css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="<?= base_url()?>assets/css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/normalize.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/style.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/responsive.css">
		
    </head>
    <body>

		


		<!-- Error Page -->
		<section class="error-page section">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 offset-lg-3 col-12">
						<!-- Error Inner -->
						<div class="error-inner">
							<h1>404<span>Oop's  sorry we can't find that page!</span></h1>


						</div>
						<!--/ End Error Inner -->
					</div>
				</div>
			</div>
		</section>	
		<!--/ End Error Page -->
		
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="<?= base_url()?>assets/js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="<?= base_url()?>assets/js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="<?= base_url()?>assets/js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="<?= base_url()?>assets/js/easing.js"></script>
		<!-- Color JS -->
		<script src="<?= base_url()?>assets/js/colors.js"></script>
		<!-- Popper JS -->
		<script src="<?= base_url()?>assets/js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="<?= base_url()?>assets/js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="<?= base_url()?>assets/js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="<?= base_url()?>assets/js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="<?= base_url()?>assets/js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="<?= base_url()?>assets/js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="<?= base_url()?>assets/js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="<?= base_url()?>assets/js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="<?= base_url()?>assets/js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="<?= base_url()?>assets/js/steller.js"></script>
		<!-- Wow JS -->
		<script src="<?= base_url()?>assets/js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="<?= base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->

		<!-- Bootstrap JS -->
		<script src="<?= base_url()?>assets/js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="<?= base_url()?>assets/js/main.js"></script>
    </body>
</html>










