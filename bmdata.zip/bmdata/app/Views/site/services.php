<?= $this->extend('site/layouts/master') ?>
<?= $this->section('title') ?>
<?php if (isset($title)) : ?>
    <?= $title ?>
<?php else : ?>
    Services
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
		<!-- Breadcrumbs -->
		<div class="breadcrumbs overlay">
			<div class="container">
				<div class="bread-inner">
					<div class="row">
						<div class="col-12">
							<h2>Services</h2>
							<ul class="bread-list">
								<li><a href="index.php">Home</a></li>
								<li><i class="icofont-simple-right"></i></li>
								<li class="active">Services</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->


        <!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Land Surveying Services</h3>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">
										<li><i class="fa fa-caret-right"></i>Topographical surveys </li>
										<li><i class="fa fa-caret-right"></i>Boundaries</li>
										<li><i class="fa fa-caret-right"></i>Building area surveys</li>
                                        <li><i class="fa fa-caret-right"></i>Land partitions</li>
                                        <li><i class="fa fa-caret-right"></i>Easement surveys</li>
                                        <li><i class="fa fa-caret-right"></i>Road layout surveys</li>
                                        <li><i class="fa fa-caret-right"></i>Pipelines, gas and oil well locations</li>
									</ul>
								</div>



								<div class="col-lg-6">
									<ul class="list">

                                    <li><i class="fa fa-caret-right"></i>Wetlands delineation</li>
                                    <li><i class="fa fa-caret-right"></i>Construction layouts</li>
                                    <li><i class="fa fa-caret-right"></i>Subdivision design</li>
                                    <li><i class="fa fa-caret-right"></i>Title and boundary surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Unit surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Specialized mapping</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service1.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->

        <!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Civil Engineering</h3>
                            <p>
                            The staff at Topographic has decades of experience in providing civil engineering and surveying for municipalities, utility and school districts, developers, engineers, architects banking institutions title companies and many others. Civil engineering and surveying services provided in the past have aided in the obtaining of the right-of-way and construction infrastructure, commercial and residential development of undeveloped property, performing ALTA/ACSM Land Title Surveys for real estate transactions, airport expansion projects, mapping for GIS databases, preparation of documents for permitting purposes and many other specialized civil engineering and surveying services for unique projects that require outside-the-box thinking. With our extensive experience, up-to-date technology in the office and the field and fine-tuned procedures geared toward efficiency, we can effectively complete your project on time within budget while providing you with the deliverable you need.
                            </p>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Zoning</li>
                                    <li><i class="fa fa-caret-right"></i>Planned Development</li>
                                    <li><i class="fa fa-caret-right"></i>Site Planning</li>
									</ul>
								</div>

								<div class="col-lg-6">
									<ul class="list">

                                    <li><i class="fa fa-caret-right"></i>Development Plans</li>
                                <li><i class="fa fa-caret-right"></i>Feasibility Studies</li>
                                <li><i class="fa fa-caret-right"></i>Land Use Planning</li>
                                <li><i class="fa fa-caret-right"></i>Specific Use Permits</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service2.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->
       
        <!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Design & Surveying Services</h3>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Civil Engineering and Land Surveying</li>
                                <li><i class="fa fa-caret-right"></i>Infrastructure research</li>
                                <li><i class="fa fa-caret-right"></i>Topographic Surveys</li>
                                <li><i class="fa fa-caret-right"></i>Lot and street layout</li>
                                <li><i class="fa fa-caret-right"></i>Drainage studies</li>
                                <li><i class="fa fa-caret-right"></i>Infrastructure Design</li>
									</ul>
								</div>




								<div class="col-lg-6">
									<ul class="list">
                                <li><i class="fa fa-caret-right"></i>Grading Plans</li>
                                <li><i class="fa fa-caret-right"></i>Annexation zoning and exhibits</li>
                                <li><i class="fa fa-caret-right"></i>Rezoning</li>
                                <li><i class="fa fa-caret-right"></i>Marketing Exhibits</li>
                                <li><i class="fa fa-caret-right"></i>Preliminary & Final Subdivision Platting</li>
                                <li><i class="fa fa-caret-right"></i>Representation at coordination and approval meetings</li>
                                <li><i class="fa fa-caret-right"></i>Construction Staking</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service3.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->


        <!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>UAV Lidar Scanner & Aerial Mapping Services</h3>
                            <p class="text-info">
                            Using an UAV Lidar Scanner, Land Surveys Can Provide Accurate Aerial Survey Services Across Ethiopia
                            </p>
                            <p>
                                <h5>
                                Land Surveys has used unmanned aerial vehicles (UAVs) since 2018 when they became commercially available in Ethiopia.
                                </h5>
                            </p>
                            <p>
                            With these UAVs, or drones as they’re more commonly known, we provide projects and businesses with aerial surveys and other survey services across Ethiopia, assisting them in their day-to-day operations.
                            </p>
                            <p>
                            We continuously invest in the latest and best technology systems and workflows, giving us a spread of experience in different projects and applications that sets Land Surveys apart as leaders in the industry.
                            </p>
                            <p>
                            Our team members house extensive experience across different industries and in utilising different technologies, providing scope for innovation and flexibility. We have traversed the trials and tribulations at the front-end, enabling us to extend and apply our knowledge and experience
                            </p>
                            <p>
                                <h5 class="text-info">
                                All UAV & Lidar Mapping Projects Start with The End Result in Mind
                                </h5>
                            </p>
                            <p>
                            We have a range of aerial platforms and state-of-the-art imaging sensors and software that enable us to deliver unparalleled, tailored data solutions to clients’ specific needs. All mapping projects start with the end result in mind, and we guide clients through the options for survey, mapping, GIS and visualisation products. We advise on the best approach to meet project quality, accuracy and time and cost goals.
                            </p>
                            <p>
                            All of Land Surveys’ operators are qualified surveyors or photogrammetrists, making Land Surveys a complete solution for project planning, ground control, image acquisition, processing, and reporting. We are early adopters of the latest, proven technology – we’ve tried and tested countless workflows – allowing our surveyors to work smarter and more efficiently.
                            </p>
							<div class="row">
                                
								<div class="col-lg-6">

                                <ul class="list">
                                    <p>
                                        UAV Aerial surveys allow clients to:
                                    </p>
                                    <li><i class="fa fa-caret-right"></i>safely track the progress of their projects
                                    </li>
                                    <li><i class="fa fa-caret-right"></i>capture large amounts of survey data and imagery over complex and large projects in a short period of time. Aerial surveys are also ideal for reporting quantities and conformance; and
                                    </li>
                                    <li><i class="fa fa-caret-right"></i>provide the best solutions ranging from a few hectares to hundreds of square kilometres.
                                    </li>
								</ul>
								</div>




								<div class="col-lg-6">

                                <ul class="list">
                                    <p>
                                    The benefits of UAV aerial surveys also include:
                                    </p>
                                    <li><i class="fa fa-caret-right"></i>safe and efficient methods of capturing large areas of survey data
                                    </li>
                                    <li><i class="fa fa-caret-right"></i>being a cost-effective option;
                                    </li>
                                    <li><i class="fa fa-caret-right"></i>high accuracy surveying – a single point of truth and reference; and
                                    </li>
								</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service4.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->





       
        <!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Our GIS/Mapping Competencies and Services</h3>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">

                                    <li><i class="fa fa-caret-right"></i>GIS Web-based Mapping (LandScape Web Mapping System)</li>
                                    <li><i class="fa fa-caret-right"></i>Preliminary Easement/Road Exhibits</li>
                                    <li><i class="fa fa-caret-right"></i>Parcel Maps/ R-O-W Status Mapping</li>
                                    <li><i class="fa fa-caret-right"></i>Regulatory-Required Deliverables)</li>
    

									</ul>
								</div>




								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>ROW, System and As-Built Maps</li>
                                    <li><i class="fa fa-caret-right"></i>GIS Alignment Sheets</li>
                                    <li><i class="fa fa-caret-right"></i>Training/Consulting</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service5.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->



        <!-- Start Why choose -->
		<section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>RENEWABLE ENERGY</h3>
                            <p>
                            As the face of energy continues to evolve, so do the requirements and expertise needed to support it. Topographic’s early adoption of innovative equipment and techniques have enabled us to stay at the forefront of surveying and engineering for Wind and Solar Energy
                            </p>
                            <p>
                                <h5 class="text-second">
                                Wind & Solar Services
                                </h5>
                            </p>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Substation Layouts</li>
                                    <li><i class="fa fa-caret-right"></i>Topographic Surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Machine Control DEM Creation</li>
                                    <li><i class="fa fa-caret-right"></i>Access Road Design</li>
                                    <li><i class="fa fa-caret-right"></i>Construction Staking</li>
                                    <li><i class="fa fa-caret-right"></i>As-Built Surveys</li>
                                     <li><i class="fa fa-caret-right"></i>Airborne and Terrestrial LiDAR</li>
                                    <li><i class="fa fa-caret-right"></i>GIS Aerial Mapping and Photogrammetry</li>
									</ul>
								</div>

								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Existing R-O-W Identification</li>
                                    <li><i class="fa fa-caret-right"></i>Bureau of Land Management (BLM) Surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Zoning Regulation Documentation</li>
                                    <li><i class="fa fa-caret-right"></i>Federal Aviation Administration (FAA) Permitting 1A/2C Certifications</li>
                                    <li><i class="fa fa-caret-right"></i>ALTA/ACSM Surveys</li>
                            
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service6.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->




   <!-- Start Why choose -->
   <section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Transmission & Distribution</h3>
                            <p>
                            We've expanded by providing professional services for the construction of electric transmission and distribution over our 65-year evolution. Today we provide professional land surveying for Right-of-Way acquisition and design, 3D Laser scanning, UAV aerial mapping and LIDAR solutions for hundreds of miles of transmission lines annually. With our extensive footprint across the Ethiopia, our relentless focus on turnaround times, quality and customer service we have become a preferred vendor for electric energy transmission and distribution development.
                            </p>
                            <p>
                                <h5 class="text-second">
                                Electric Transmission & Distribution Services

                                </h5>
                            </p>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Substation & Switch Yard Layouts</li>
                                    <li><i class="fa fa-caret-right"></i>Microwave Tower Sites</li>
                                    <li><i class="fa fa-caret-right"></i>Route Design Surveys with Plan and Profile Sheets</li>
                                    <li><i class="fa fa-caret-right"></i>Grading Plans</li>
                                    <li><i class="fa fa-caret-right"></i>Federal Aviation Administration (FAA) Permitting 1A/2C Certifications</li>
									</ul>
								</div>

								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>As-Built Surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Bureau of Land Management (BLM) Surveys</li>
                                    <li><i class="fa fa-caret-right"></i>ALTA/ACSM Surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Airborne and Terrestrial LiDAR</li>
                                    <li><i class="fa fa-caret-right"></i>GIS Aerial Mapping and Photogrammetry</li>
                            
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service7.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->


       <!-- Start Why choose -->
       <section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Land Development</h3>
                            <p>
                            Our background in the public sector gives us the ability to more readily anticipate and effectively communicate with municipalities on land development projects. Having this unique background can make the difference between success and failure. We have many years of experience in everything involved in land development, from infrastructure assessment and design, to rezoning and the many other aspects that involve bringing development from raw land to fully constructed.

                            </p>
                            <p>
                                <h5>
                                A Full Range of Development Services
                                </h5>
                            </p>
							<div class="row">
								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Surveying and Engineering</li>
                                    <li><i class="fa fa-caret-right"></i>Site Feasibility/Due Diligence</li>
                                    <li><i class="fa fa-caret-right"></i>Entitlement</li>
                                    <li><i class="fa fa-caret-right"></i>Topographic surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Boundary survey for transaction with easement review</li>
                                    <li><i class="fa fa-caret-right"></i>Infrastructure research</li>


									</ul>
								</div>

								<div class="col-lg-6">
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Preliminary and Final lot and street layout</li>
                                    <li><i class="fa fa-caret-right"></i>Drainage studies</li>
                                    <li><i class="fa fa-caret-right"></i>Annexation and zoning exhibits</li>
                                    <li><i class="fa fa-caret-right"></i>Rezoning</li>
                                    <li><i class="fa fa-caret-right"></i>Preliminary & Final Subdivision Platting</li>
                                    <li><i class="fa fa-caret-right"></i>Representation at coordination and approval</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service8.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->

    <!-- Start Why choose -->
       <section class="why-choose section" >
			<div class="container">

				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- Start Choose Left -->
						<div class="choose-left">
							<h3>Oil and Gas Surveying</h3>
                            <p>
                            We understand that strict time, accuracy and compliance fuel your profitability. With this in mind, Topographic offers comprehensive services designed around your Oil and Gas surveying needs. With a presence in almost every major shale play across the Ethiopia and a staff of 20 Professional Land Surveyors, 5+ draftsmen, 20+ crews and a dedicated GIS department
                            </p>
							<div class="row">
								<div class="col-lg-6">
                                    <p>
                                        <h5>
                                        Exploration and Production
                                        </h5>
                                    </p>
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Well staking</li>
                                    <li><i class="fa fa-caret-right"></i>Establish oil and gas drilling unit acreage</li>
                                    <li><i class="fa fa-caret-right"></i>Bureau of Land Management (BLM) surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Boundary surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Frac ponds</li>
                                    <li><i class="fa fa-caret-right"></i>Lease road exhibits</li>
                                    <li><i class="fa fa-caret-right"></i>Salt water disposal pipelines</li>
                                    <li><i class="fa fa-caret-right"></i>Permitting for regulatory agencies (AOGC, ADEQ)</li>
                                    <li><i class="fa fa-caret-right"></i>Containment & volume surveys</li>

									</ul>
								</div>

								<div class="col-lg-6">
                                    <p>
                                        <h5>
                                        Pipeline Surveying
                                        </h5>
                                    </p>
									<ul class="list">
                                    <li><i class="fa fa-caret-right"></i>Construction survey support</li>
                                    <li><i class="fa fa-caret-right"></i>Site development/layout</li>
                                    <li><i class="fa fa-caret-right"></i>Plats and legal descriptions for easements acquisition</li>
                                    <li><i class="fa fa-caret-right"></i>Deed research</li>
                                    <li><i class="fa fa-caret-right"></i>Boundary surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Construction route survey / staking</li>
                                    <li><i class="fa fa-caret-right"></i>Preliminary route development plan & profile alignments</li>
                                    <li><i class="fa fa-caret-right"></i>As-Built Surveys</li>
                                    <li><i class="fa fa-caret-right"></i>Directional bore designs & exhibits</li>

									</ul>
								</div>
							</div>
						</div>
						<!-- End Choose Left -->
					</div>
					<div class="col-lg-6 col-12">
						<!-- Start Choose Rights -->
						<div class="choose-right" style="background-image:url('assets/img/bmk_service9.jpg');">
							<div class="video-image">
								<!-- Video Animation -->
								<div class="promo-video">
									<div class="waves-block">
										<div class="waves wave-1"></div>
										<div class="waves wave-2"></div>
										<div class="waves wave-3"></div>
									</div>
								</div>
								<!--/ End Video Animation -->
								<a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
							</div>
						</div>
						<!-- End Choose Rights -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->

					</div>
				</div>
			</div>
		</section>
		<!--/ End Why choose -->


<?= $this->endSection()?>