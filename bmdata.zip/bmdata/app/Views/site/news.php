<?php
	function truncateText($text, $maxChars) {
		if (strlen($text) > $maxChars) {
			$truncatedText = substr($text, 0, $maxChars);
			echo $truncatedText . ' ...';
			return true;
		} else {
			echo $text;
			return false;
		}
	}
	?>
<?= $this->extend('site/layouts/master') ?>
<?= $this->section('title') ?>
<?php if (isset($title)) : ?>
    <?= $title ?>
<?php else : ?>
    News
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
	<!-- Breadcrumbs -->
	<div class="breadcrumbs overlay">
			<div class="container">
				<div class="bread-inner">
					<div class="row">
						<div class="col-12">
							<h2>News</h2>
							<ul class="bread-list">
								<li><a href="index.php">Home</a></li>
								<li><i class="icofont-simple-right"></i></li>
								<li class="active">News</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->
		<!-- Single News -->
		<section class="news-single section">
			<div class="container">
				<div class="row">
				<div class="col-md-12">
						<div class="row">
							<?php if(isset($news)):?>
								<?php foreach($news as $news_):?>
							<div class="col-md-4">
								<div class="single-main">
									<!-- News Head -->
									<div class="news-head">
										<img src="<?= base_url()?>bmk/images/blog/<?= $news_['image_url']?>" alt="#">
									</div>
									<!-- News Title -->
									<h1 class="news-title"><a href="<?= base_url()?>news/detail/<?= $news_['id']?>"><?= $news_['title']?></a></h1>
									<!-- Meta -->
									<div class="meta">
										<div class="meta-left">
											<!-- <span class="author"><a href="#"><img src="img/author1.jpg" alt="#">name</a></span> -->
											<span class="date"><i class="fa fa-clock-o"></i><?php $d = new dateTime($news_['created_at']); echo $d->format('d M Y');?></span>
										</div>
										<div class="meta-right">
										</div>
									</div>
									<!-- News Text -->
									<div class="news-text">

										<p><?php truncateText($news_['content'], 100)?></p>
									</div>

								</div>
							</div>
							<?php endforeach;?>
							<?php else: ?>
								<p>No content</p>
							<?php endif?>

						</div>
	
						<div class="pagination-container">
						<li class="prev"><?= $pager->links()?></li>
							</div>
					</div>
					
				</div>
			</div>
		</section>
		<!--/ End Single News -->


<?= $this->endSection()?>

