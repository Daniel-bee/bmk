<?= $this->extend('site/layouts/master') ?>
<?= $this->section('title') ?>
<?php if (isset($title)) : ?>
    <?= $title ?>
<?php else : ?>
    About
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>

	
		<!-- Breadcrumbs -->
		<div class="breadcrumbs overlay">
			<div class="container">
				<div class="bread-inner">
					<div class="row">
						<div class="col-12">
							<h2>News Details</h2>
							<ul class="bread-list">
								<li><a href="index.php">Home</a></li>
								<li><i class="icofont-simple-right"></i></li>
								<li class="active">News Details</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->
		
		<!-- Single News -->
		<section class="news-single section">
			<div class="container">
				<div class="row">
					<div class="col-12">

						<div class="row">
							<div class="col-12">
								<div class="single-main">
									<!-- News Head -->
									<div class="news-head">
										<img src="<?= base_url()?>bmk/images/blog/<?= $news['image_url']?>" alt="#">
									</div>
									<!-- News Title -->
									<h1 class="news-title">
									<?= $news['title'];?>
									</h1>
									<!-- Meta -->
									<div class="meta">
										<div class="meta-left">
											<span class="date"><i class="fa fa-clock-o"></i><?php $d = new DateTime($news['created_at']); echo $d->format('d M Y');?></span>
										</div>
										<!-- <div class="meta-right">
											<span class="comments"><a href="#"><i class="fa fa-comments"></i>05 Comments</a></span>
											<span class="views"><i class="fa fa-eye"></i>33K Views</span>
										</div> -->
									</div>
									<!-- News Text -->
									<div class="news-text">
										<p><?= $news['content'];?></p>
									</div>

								</div>
							</div>

						</div>


					</div>


			


				</div>
			</div>
		</section>
		<!--/ End Single News -->
		


<?= $this->endSection()?>