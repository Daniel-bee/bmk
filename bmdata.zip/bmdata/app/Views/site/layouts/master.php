<!doctype html>
<html>

<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="keywords" content="Site keywords here">
    <meta name="description" content="">
    <meta name='copyright' content=''>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> -->

    <!-- Title -->
    <title><?= $this->renderSection('title') ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?= base_url() ?>bmk/images/favicon.png">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/nice-select.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/font-awesome.min.css">
    <!-- icofont CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/icofont.css">
    <!-- Slicknav -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/slicknav.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/owl-carousel.css">
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/datepicker.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/animate.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/magnific-popup.css">

    <!-- Medipro CSS -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/normalize.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/style.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/responsive.css">

</head>

<body>

    <!-- Preloader -->


    <!-- End Preloader -->

    <!-- Get Pro Button -->


    <!-- Header Area -->
    <header class="header">
        <!-- Topbar -->
        <div class="topbar">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-5 col-12">
                        <!-- Contact -->
                        <ul class="top-link">
                            <li><a href="<?= base_url()?>about">About</a></li>
                            <li><a href="<?= base_url()?>contactus">Contact</a></li>
                        </ul>
                        <!-- End Contact -->
                    </div>
                    <div class="col-lg-6 col-md-7 col-12">
                        <!-- Top Contact -->
                        <ul class="top-contact">
                            <li><i class="fa fa-phone"></i>+251 1234 56789</li>
                            <li><i class="fa fa-envelope"></i><a href="mailto:support@yourmail.com">support@yourmail.com</a></li>
                        </ul>
                        <!-- End Top Contact -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Topbar -->
        <!-- Header Inner -->
        <div class="header-inner">
            <div class="container">
                <div class="inner">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-12">
                            <!-- Start Logo -->
                            <div class="logo">
                                <a href="index.php">
                                    <img src="<?= base_url()?>assets/img/logo1.jpg" style="height:40px;" alt="logo">
                                </a>
                            </div>
                            <!-- End Logo -->
                            <!-- Mobile Nav -->
                            <div class="mobile-nav"></div>
                            <!-- End Mobile Nav -->
                        </div>
                        <div class="col-lg-7 col-md-9 col-12">
                            <!-- Main Menu -->
                            <div class="main-menu">
                                <nav class="navigation">
                                    <ul class="nav menu">
                                        <li id="menu1">
                                            <a href="<?= base_url()?>">Home</a>
                                        </li>
                                        <li class="custom-dropdown-about">
                                            <a href="#">About <i class="icofont-rounded-down"></i></a>
                                            <div class="custom-dropdown-content-about">

                                            <!-- Content for the dropdown -->
                                            <div class="row">
                                            <div class="col-md-6">
                                                <div class="main-category "><a href="#" class="custom-link">Our Team</a></div>
                                                <div class="main-category "><a href="#" class="custom-link">Projects</a></div>
                                            </div>
                                            </div>
                                            
                                            </div>
                                        </li>
                                        <li class="custom-dropdown">
                                            <a href="#">Services <i class="icofont-rounded-down"></i></a>
                                            <div class="custom-dropdown-content">

                                            <!-- Content for the dropdown -->
                                            <div class="row">
                                            <div class="col-md-6">
                                                <div class="main-category "><a href="#" class="custom-link">LAND SURVEYING</a></div>
                                                <div class="main-category"><a href="#" class="custom-link">OIL & GAS</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">UPSTREAM</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">MIDSTREAM</a></div>
                                                <div class="main-category"><a href="#" class="custom-link">CIVIL ENGINEERING</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">DEVELOPMENT SERVICES</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">CIVIL SURVEYING</a></div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="main-category"><a href="#" class="custom-link">ENVIRONMENTAL</a></div>
                                                <div class="main-category"><a href="#" class="custom-link">ENVIRONMENTAL REMEDIATION</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">EXCAVATION & TANK REMOVAL</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">FIELD SERVICES</a></div>
                                                <div class="sub-category"><a href="" class="sub-custom-link">DRILLING</a></div>
                                                <div class="main-category"><a href="#" class="custom-link">UAV/DRONES</a></div>
                                                <div class="main-category"><a href="#" class="custom-link">HD SCANNING</a></div>
                                                <div class="main-category"><a href="#" class="custom-link">GIS & MAPPING</a></div>
                                            </div>
                                            </div>
                                            
                                            </div>
                                        </li>
                                        <li  id="menu4">
                                            <a href="<?= base_url()?>news">News</a>
                                        </li>
                                        
                                        <li  id="menu5"><a href="<?= base_url()?>contactus">Contact Us</a></li>



                                    </ul>
                                </nav>
                            </div>
                            <!--/ End Main Menu -->
                        </div>

                    </div>
                </div>


                
            </div>
        </div>

        

        <!--/ End Header Inner -->
    </header>
    <!-- End Header Area -->

        <?= $this->renderSection('content')?>

    <!-- Footer Area -->
    <footer id="footer" class="footer ">
        <!-- Footer Top -->
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-footer">
                            <h2>About Us</h2>
                            <p>Lorem ipsum dolor sit am consectetur adipisicing elit do eiusmod tempor incididunt ut labore dolore magna.</p>
                            <!-- Social -->
                            <ul class="social">
                                <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                <li><a href="#"><i class="icofont-linkedin"></i></a></li>
                                <li><a href="#"><i class="icofont-twitter"></i></a></li>
                            </ul>
                            <!-- End Social -->
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-footer f-link">
                            <h2>Quick Links</h2>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-12">
                                    <ul>
                                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Home</a></li>
                                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Our Team</a></li>
                                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Projects</a></li>
                                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>News</a></li>
                                        <!-- <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>Other Links</a></li>	 -->
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-footer">
                            <h2>Info</h2>
                            <p>Lorem ipsum dolor sit ame consectetur adipisicing elit do eiusmod tempor incididunt.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-footer">
                            <h2>BMK-GEOINFORMATICS</h2>
                            <img src="assets/img/logo1.jpg" height="50" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Footer Top -->
        <!-- Copyright -->
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="copyright-content">
                            <p>© Copyright <?= date('Y') ?> | All Rights Reserved <a href="<?= base_url()?>">BMK GEO-INFORMATICS</a> </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Copyright -->
    </footer>
    <!--/ End Footer Area -->

    <!-- jquery Min JS -->
    <script src="<?=base_url()?>assets/js/jquery.min.js"></script>
    <!-- jquery Migrate JS -->
    <script src="<?=base_url()?>assets/js/jquery-migrate-3.0.0.js"></script>
    <!-- jquery Ui JS -->
    <script src="<?=base_url()?>assets/js/jquery-ui.min.js"></script>
    <!-- Easing JS -->
    <script src="<?=base_url()?>assets/js/easing.js"></script>
    <!-- Color JS -->
    <script src="<?=base_url()?>assets/js/colors.js"></script>
    <!-- Popper JS -->
    <script src="<?=base_url()?>assets/js/popper.min.js"></script>
    <!-- Bootstrap Datepicker JS -->
    <script src="<?=base_url()?>assets/js/bootstrap-datepicker.js"></script>
    <!-- Jquery Nav JS -->
    <script src="<?=base_url()?>assets/js/jquery.nav.js"></script>
    <!-- Slicknav JS -->
    <script src="<?=base_url()?>assets/js/slicknav.min.js"></script>
    <!-- ScrollUp JS -->
    <script src="<?=base_url()?>assets/js/jquery.scrollUp.min.js"></script>
    <!-- Niceselect JS -->
    <script src="<?=base_url()?>assets/js/niceselect.js"></script>
    <!-- Tilt Jquery JS -->
    <script src="<?=base_url()?>assets/js/tilt.jquery.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="<?=base_url()?>assets/js/owl-carousel.js"></script>
    <!-- counterup JS -->
    <script src="<?=base_url()?>assets/js/jquery.counterup.min.js"></script>
    <!-- Steller JS -->
    <script src="<?=base_url()?>assets/js/steller.js"></script>
    <!-- Wow JS -->
    <script src="<?=base_url()?>assets/js/wow.min.js"></script>
    <!-- Magnific Popup JS -->
    <script src="<?=base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Counter Up CDN JS -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <!-- Main JS -->
    <script src="<?=base_url()?>assets/js/main.js"></script>

    <script>
    $(document).ready(function() {
      // Retrieve the active menu item from localStorage on page load
      var activeMenuId = localStorage.getItem('activeMenuId');

      if (activeMenuId) {
        $('#' + activeMenuId).addClass('active');
      }

      $('li').click(function() {
        // Remove 'active' class from all menu items
        $('li').removeClass('active');

        // Add 'active' class to the clicked menu item
        $(this).addClass('active');

        // Store the active menu item ID in localStorage
        localStorage.setItem('activeMenuId', $(this).attr('id'));
      });
    });

    document.addEventListener("DOMContentLoaded", function() {
      // make it as accordion for smaller screens
      if (window.innerWidth < 992) {

        // close all inner dropdowns when parent is closed
        document.querySelectorAll('.navbar .dropdown').forEach(function(everydropdown) {
          everydropdown.addEventListener('hidden.bs.dropdown', function() {
            // after dropdown is hidden, then find all submenus
            this.querySelectorAll('.submenu').forEach(function(everysubmenu) {
              // hide every submenu as well
              everysubmenu.style.display = 'none';
            });
          })
        });

        document.querySelectorAll('.dropdown-menu a').forEach(function(element) {
          element.addEventListener('click', function(e) {
            let nextEl = this.nextElementSibling;
            if (nextEl && nextEl.classList.contains('submenu')) {
              // prevent opening link if link needs to open dropdown
              e.preventDefault();
              if (nextEl.style.display == 'block') {
                nextEl.style.display = 'none';
              } else {
                nextEl.style.display = 'block';
              }

            }
          });
        })
      }
      // end if innerWidth
    });
  </script>
</body>

</html>