<?= $this->extend('site/layouts/master') ?>
<?= $this->section('title') ?>
<?php if (isset($title)) : ?>
    <?= $title ?>
<?php else : ?>
    Home
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>

<!-- Slider Area -->
<section class="slider">
    <div class="hero-slider">
        <!-- Start Single Slider -->
        <div class="single-slider" style="background-image:url('assets/img/bmk_slide1.jpg')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="text">

                            <h1 style="color:beige;">Computers do the <span>hard</span> part. It's still our job to do the<span>smart part.</span></h1>
                            <p style="color:beige;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sed nisl pellentesque, faucibus libero eu, gravida quam. </p>
                            <!-- <div class="button">
										<a href="#" class="btn">Get Appointment</a>
										<a href="#" class="btn primary">Learn More</a>
									</div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Single Slider -->
        <!-- Start Single Slider -->
        <div class="single-slider" style="background-image:url('assets/img/bmk_slide2.jpg')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="text">

                            <h1 style="color:beige;">Computers do the <span>hard</span> part. It's still our job to do the<span>smart part.</span></h1>
                            <p style="color:beige;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sed nisl pellentesque, faucibus libero eu, gravida quam. </p>
                            <!-- <div class="button">
										<a href="#" class="btn">Get Appointment</a>
										<a href="#" class="btn primary">Learn More</a>
									</div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Single Slider -->
        <!-- Start Single Slider -->
        <div class="single-slider" style="background-image:url('assets/img/bmk_slide3.jpg')">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <div class="text ">

                            <h1 style="color:beige;">Computers do the <span>hard</span> part. It's still our job to do the<span>smart part.</span></h1>
                            <p style="color:beige;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sed nisl pellentesque, faucibus libero eu, gravida quam. </p>
                            <!-- <div class="button">
										<a href="#" class="btn">Get Appointment</a>
										<a href="#" class="btn primary">Learn More</a>
									</div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Single Slider -->
    </div>
</section>
<!--/ End Slider Area -->




<!-- Start Why choose -->
<section class="why-choose section">
    <div class="container">

        <div class="row">
            <div class="col-lg-6 col-12">
                <!-- Start Choose Left -->
                <div class="choose-left">
                    <h3>Who We Are</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pharetra antege vel est lobortis, a commodo magna rhoncus. In quis nisi non emet quam pharetra commodo. </p>
                    <p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. </p>
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list">
                                <li><i class="fa fa-caret-right"></i>Civil Engineering and Land Surveying </li>
                                <li><i class="fa fa-caret-right"></i>Infrastructure research</li>
                                <li><i class="fa fa-caret-right"></i>Topographic Surveys</li>
                            </ul>
                        </div>
                        <div class="col-lg-6">
                            <ul class="list">
                                <li><i class="fa fa-caret-right"></i>Building area surveys </li>
                                <li><i class="fa fa-caret-right"></i>Pipelines, gas and oil well locations</li>
                                <li><i class="fa fa-caret-right"></i>Title and boundary surveys</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- End Choose Left -->
            </div>
            <div class="col-lg-6 col-12">
                <!-- Start Choose Rights -->
                <div class="choose-right">
                    <div class="video-image">
                        <!-- Video Animation -->
                        <div class="promo-video">
                            <div class="waves-block">
                                <div class="waves wave-1"></div>
                                <div class="waves wave-2"></div>
                                <div class="waves wave-3"></div>
                            </div>
                        </div>
                        <!--/ End Video Animation -->
                        <a href="https://www.youtube.com/watch?v=RFVXy6CRVR4" class="video video-popup mfp-iframe"><i class="fa fa-play"></i></a>
                    </div>
                </div>
                <!-- End Choose Rights -->
            </div>
        </div>
    </div>
</section>
<!--/ End Why choose -->



<!-- Start portfolio -->
<section class="portfolio section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h2>Recent Posts</h2>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-12 col-12 ">
                <div class="owl-carousel portfolio-slider ">

                <?php if(isset($news)):?>
                    <?php foreach($news as $news_):?>
                    <div class="single-pf ">
                        <img src="<?= base_url()?>bmk/images/blog/<?= $news_['image_url']?>" alt="#">
                        <a href="<?= base_url()?>news/detail/<?= $news_['id']?>" class="btn">View Details</a>
                    </div>
                    <?php endforeach;?>
                <?php endif;?>

                </div>
            </div>
        </div>
    </div>
</section>
<!--/ End portfolio -->



<!-- Start Blog Area -->
<section class="blog section" id="blog">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h2>What We Do</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 col-12">
                <!-- Single Blog -->
                <div class="single-news">
                    <div class="news-head">
                        <img src="assets/img/bmk_team1.jpg" alt="#">
                    </div>
                    <div class="news-body">
                        <div class="news-content">
                            <!-- <div class="date">22 Aug, 2020</div> -->
                            <h2><a href="blog-single.html">Civil Engineering</a></h2>
                            <p class="text">
                                The staff at Topographic has decades of experience in providing civil engineering and surveying for municipalities, utility and school districts,
                                developers, engineers, architects banking institutions title companies and many others.
                            </p>
                        </div>
                    </div>
                </div>
                <!-- End Single Blog -->
            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <!-- Single Blog -->
                <div class="single-news">
                    <div class="news-head">
                        <img src="assets/img/bmk_team2.jpg" alt="#">
                    </div>
                    <div class="news-body">
                        <div class="news-content">
                            <!-- <div class="date">15 Jul, 2020</div> -->
                            <h2><a href="blog-single.html">UAV Lidar Scanner & Aerial Mapping Services</a></h2>
                            <p class="text">
                                With these UAVs, or drones as they’re more commonly known, we provide projects and
                                businesses with aerial surveys and other
                                survey services across Ethiopia, assisting them in their day-to-day operations.
                            </p>
                        </div>
                    </div>
                </div>
                <!-- End Single Blog -->
            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <!-- Single Blog -->
                <div class="single-news">
                    <div class="news-head">
                        <img src="assets/img/bmk_team3.jpg" alt="#">
                    </div>
                    <div class="news-body">
                        <div class="news-content">
                            <!-- <div class="date">05 Jan, 2020</div> -->
                            <h2><a href="blog-single.html">Design & Surveying Services.</a></h2>
                            <p class="text">
                                Civil Engineering and Land Surveying, Infrastructure research,
                                Topographic Surveys, Lot and street layout, Drainage studies,
                                Infrastructure Design, Grading Plans, Annexation zoning and exhibits,
                                Rezoning

                            </p>
                        </div>
                    </div>
                </div>
                <!-- End Single Blog -->
            </div>
        </div>
    </div>
</section>
<!-- End Blog Area -->
<?= $this->endSection()?>