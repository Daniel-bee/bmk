<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('about/', 'Home::about');
$routes->get('services/', 'Home::services');
$routes->get('news/', 'Home::news');
$routes->get('news/detail/(:num)', 'Home::newsDetail/$1');
$routes->get('contactus/', 'Home::contactus');

$routes->group('bmkad', ['namespace' => 'App\Controllers\Bmk'], function($routes){

    $routes->get('/', 'User::signin');
    $routes->get('signup/', 'User::signup');
    $routes->post('user/create', 'User::storeUser');
    $routes->post('authenticate/', 'User::authenticate');
    $routes->get('profile/(:num)', 'User::profile/$1', ['filter' => 'admin']);
    $routes->put('user/update/(:num)', 'User::updateUser/$1', ['filter' => 'admin']);
    $routes->put('user/changepassword/(:num)', 'User::updatePassword/$1', ['filter' => 'admin']);
    $routes->get('user/upload', 'User::updateImage', ['filter' => 'admin']);
    $routes->get('logout/', 'User::logout', ['filter' => 'admin']);
    $routes->get('dashboard/', 'Dashboard::index',['filter' => 'admin']);

    $routes->get('blog/create', 'Blog::blogCreate', ['filter' => 'admin']);
    $routes->post('blog/store', 'Blog::blogStore', ['filter' => 'admin']);
    $routes->get('blog/detail', 'Blog::blogDetail', ['filter' => 'admin']);
    $routes->get('blog/edit/(:num)', 'Blog::blogEdit/$1', ['filter' => 'admin']);
    $routes->get('blog/delete/(:num)', 'Blog::blogDestroy/$1', ['filter' => 'admin']);
    $routes->put('blog/update/(:num)', 'Blog::blogUpdate/$1', ['filter' => 'admin']);


});